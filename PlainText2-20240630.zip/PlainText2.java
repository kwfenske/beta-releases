/*
  Plain Text #2 - Convert Unicode Characters to Plain Text
  Written by: Keith Fenske, http://kwfenske.github.io/
  Monday, 16 March 2009
  Java class name: PlainText2
  Copyright (c) 2009 by Keith Fenske.  GNU General Public License (GPLv3+).

  This is a Java 1.4 graphical (GUI) application to convert Unicode characters
  to plain text characters, for example, to convert left and right quotation
  marks into plain quotes for web pages.  Since everyone has a different idea
  about what "plain text" means, the conversion is controlled by a
  configuration file that can be easily edited.

  The program presents you with a single large text area and a few buttons or
  options above.  You may edit the text area in a normal manner, including
  Control-C and Control-V keys for selective copy and paste.  The "Copy" and
  "Paste" buttons above the text area affect the entire text: the "Copy" button
  copies all text to the system clipboard ignoring any current selection, and
  the "Paste" button replaces the entire text area with the contents of the
  clipboard.  No conversion takes place until you click the "Convert" button.
  The typical sequence of actions is to copy text from a Unicode-aware
  application such as Microsoft Word, switch to this Java application, click
  the "Paste" and "Convert" buttons, then copy the converted text to another
  application that expects a more limited character set.

  GNU General Public License (GPL)
  --------------------------------
  PlainText2 is free software: you can redistribute it and/or modify it under
  the terms of the GNU General Public License as published by the Free Software
  Foundation, either version 3 of the License or (at your option) any later
  version.  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program.  If not, see the http://www.gnu.org/licenses/ web page.

  Graphical Versus Console Application
  ------------------------------------
  The Java command line may contain options for the position and size of the
  application window, and for the size of the display font.  See the "-?"
  option for a help summary:

      java  PlainText2  -?

  An option such as -u14 or -u16 is recommended because the default Java font
  is too small.

  Restrictions and Limitations
  ----------------------------
  A configuration file called "PlainText2.txt" is expected to be in the current
  working directory and contains the character conversion table.  You should
  edit this file so that it has only the changes you want.  Please read
  comments in the file for further instructions.  Characters are processed in
  their 16-bit or UTF-16 form.  To translate Unicode characters above U+FFFF,
  you must convert high and low surrogate pairs.  See also any "Character Map"
  application.
*/

import java.awt.*;                // older Java GUI support
import java.awt.event.*;          // older Java GUI event support
import java.io.*;                 // standard I/O
import java.text.*;               // number formatting
import java.util.*;               // calendars, dates, lists, maps, vectors
import java.util.regex.*;         // regular expressions
import javax.swing.*;             // newer Java GUI support

public class PlainText2
{
  /* constants */

  static final String COPYRIGHT_NOTICE =
    "Copyright (c) 2009 by Keith Fenske.  GNU General Public License (GPLv3+).";
  static final String DEFAULT_FILE = "PlainText2.txt"; // configuration data
  static final int DEFAULT_HEIGHT = -1; // default window height in pixels
  static final int DEFAULT_LEFT = 50; // default window left position ("x")
  static final int DEFAULT_TOP = 50; // default window top position ("y")
  static final int DEFAULT_WIDTH = -1; // default window width in pixels
  static final String EMPTY_STATUS = ""; // message when no status to display
  static final String[] FONT_SIZES = {"10", "12", "14", "16", "18", "20", "24",
    "30"};                        // point sizes for text in output text area
  static final Integer LEAF_KEY = new Integer(-1); // mapping key for leaves
  static final int MIN_FRAME = 200; // minimum window height or width in pixels
  static final String PROGRAM_TITLE =
    "Convert Unicode Characters to Plain Text - by: Keith Fenske";
  static final String SYSTEM_FONT = "Dialog"; // this font is always available
  static final String[] WRAP_CHOICES = {"None", "Characters", "Words"};
                                  // descriptions for <wrapIndex> values

  /* class variables */

  static JButton convertButton;   // "Convert" button: conversion of text area
  static TreeMap convertMap;      // conversion map for Unicode characters
  static JButton copyButton;      // "Copy" button: copy all text to clipboard
  static String dataFile;         // text file with configuration data
  static JButton exitButton;      // "Exit" button for ending this application
  static String fontName;         // font name for text in output text area
  static JComboBox fontNameDialog; // graphical option for <fontName>
  static int fontSize;            // point size for text in output text area
  static JComboBox fontSizeDialog; // graphical option for <fontSize>
  static NumberFormat formatComma; // formats with commas (digit grouping)
  static JFrame mainFrame;        // this application's window if GUI
  static boolean mswinFlag;       // true if running on Microsoft Windows
  static JButton multiButton;     // multiple button: Paste + Convert + Copy
  static JTextArea outputText;    // text area where we convert, copy, paste
  static JButton pasteButton;     // "Paste" button: get text from clipboard
  static JLabel statusDialog;     // status message during extended processing
  static JComboBox wrapDialog;    // graphical option for <wrapIndex>
  static int wrapIndex;           // how we wrap text lines in main dialog box

/*
  main() method

  We run as a graphical application only.  Set the window layout and then let
  the graphical interface run the show.
*/
  public static void main(String[] args)
  {
    ActionListener action;        // our shared action listener
    Font buttonFont;              // font for buttons, labels, status, etc
    int gapSize;                  // basis for pixel gap between GUI elements
    int i;                        // index variable
    boolean maximizeFlag;         // true if we maximize our main window
    int windowHeight, windowLeft, windowTop, windowWidth;
                                  // position and size for <mainFrame>
    String word;                  // one parameter from command line

    /* Initialize variables used by both console and GUI applications. */

    buttonFont = null;            // by default, don't use customized font
    convertMap = new TreeMap();   // create empty mapping for char conversions
    dataFile = DEFAULT_FILE;      // default file name for configuration data
    fontName = "Verdana";         // preferred font name for output text area
    fontSize = 16;                // default point size for output text area
    gapSize = 12;                 // default pixel gap if no font size given
    maximizeFlag = false;         // by default, don't maximize our main window
    mswinFlag = System.getProperty("os.name").startsWith("Windows");
    windowHeight = DEFAULT_HEIGHT; // default window position and size
    windowLeft = DEFAULT_LEFT;
    windowTop = DEFAULT_TOP;
    windowWidth = DEFAULT_WIDTH;
    wrapIndex = 2;                // try to wrap text lines at word boundaries

    /* Initialize number formatting styles. */

    formatComma = NumberFormat.getInstance(); // current locale
    formatComma.setGroupingUsed(true); // use commas or digit groups

    /* Check command-line parameters for options. */

    for (i = 0; i < args.length; i ++)
    {
      word = args[i].toLowerCase(); // easier to process if consistent case
      if (word.length() == 0)
      {
        /* Ignore null parameters, which are more common that you might think,
        when programs are being run from inside scripts (command files). */
      }

      else if (word.equals("?") || word.equals("-?") || word.equals("/?")
        || word.equals("-h") || (mswinFlag && word.equals("/h"))
        || word.equals("-help") || (mswinFlag && word.equals("/help")))
      {
        showHelp();               // show help summary
        System.exit(0);           // exit application after printing help
      }

      else if (word.startsWith("-d") || (mswinFlag && word.startsWith("/d")))
        dataFile = args[i].substring(2); // accept anything for data file name

      else if (word.equals("-r0") || (mswinFlag && word.equals("/r0")))
        wrapIndex = 0;            // don't wrap text in main dialog box
      else if (word.equals("-r1") || (mswinFlag && word.equals("/r1")))
        wrapIndex = 1;            // wrap text at arbitrary characters
      else if (word.equals("-r2") || (mswinFlag && word.equals("/r2")))
        wrapIndex = 2;            // wrap text at word boundaries

      else if (word.startsWith("-u") || (mswinFlag && word.startsWith("/u")))
      {
        /* This option is followed by a font point size that will be used for
        buttons, dialogs, labels, etc. */

        int size = -1;            // default value for font point size
        try                       // try to parse remainder as unsigned integer
        {
          size = Integer.parseInt(word.substring(2));
        }
        catch (NumberFormatException nfe) // if not a number or bad syntax
        {
          size = -1;              // set result to an illegal value
        }
        if ((size < 10) || (size > 99))
        {
          System.err.println("Dialog font size must be from 10 to 99: "
            + args[i]);           // notify user of our arbitrary limits
          showHelp();             // show help summary
          System.exit(-1);        // exit application after printing help
        }
        buttonFont = new Font(SYSTEM_FONT, Font.PLAIN, size); // for big sizes
//      buttonFont = new Font(SYSTEM_FONT, Font.BOLD, size); // for small sizes
        fontSize = size;          // use same point size for output text font
        gapSize = size;           // same size becomes basis for GUI pixel gap
      }

      else if (word.startsWith("-w") || (mswinFlag && word.startsWith("/w")))
      {
        /* This option is followed by a list of four numbers for the initial
        window position and size.  All values are accepted, but small heights
        or widths will later force the minimum packed size for the layout. */

        Pattern pattern = Pattern.compile(
          "\\s*\\(\\s*(\\d{1,5})\\s*,\\s*(\\d{1,5})\\s*,\\s*(\\d{1,5})\\s*,\\s*(\\d{1,5})\\s*\\)\\s*");
        Matcher matcher = pattern.matcher(word.substring(2)); // parse option
        if (matcher.matches())    // if option has proper syntax
        {
          windowLeft = Integer.parseInt(matcher.group(1));
          windowTop = Integer.parseInt(matcher.group(2));
          windowWidth = Integer.parseInt(matcher.group(3));
          windowHeight = Integer.parseInt(matcher.group(4));
        }
        else                      // bad syntax or too many digits
        {
          System.err.println("Invalid window position or size: " + args[i]);
          showHelp();             // show help summary
          System.exit(-1);        // exit application after printing help
        }
      }

      else if (word.equals("-x") || (mswinFlag && word.equals("/x")))
        maximizeFlag = true;      // true if we maximize our main window

      else                        // parameter is not a recognized option
      {
        System.err.println("Option not recognized: " + args[i]);
        showHelp();               // show help summary
        System.exit(-1);          // exit application after printing help
      }
    }

    /* Open the graphical user interface (GUI).  The standard Java style is the
    most reliable, but you can switch to something closer to the local system,
    if you want. */

//  try
//  {
//    UIManager.setLookAndFeel(
//      UIManager.getCrossPlatformLookAndFeelClassName());
////    UIManager.getSystemLookAndFeelClassName());
//  }
//  catch (Exception ulafe)
//  {
//    System.err.println("Unsupported Java look-and-feel: " + ulafe);
//  }

    /* Initialize shared graphical objects. */

    action = new PlainText2User(); // create our shared action listener

    /* If our preferred font is not available for the output text area, then
    use the boring default font for the local system. */

    if (fontName.equals((new Font(fontName, Font.PLAIN, fontSize)).getFamily())
      == false)                   // create font, read back created name
    {
      fontName = SYSTEM_FONT;     // must replace with standard system font
    }

    /* Create the graphical interface as a series of little panels inside
    bigger panels.  The intermediate panel names are of no lasting importance
    and hence are only numbered (panel1, panel2, etc). */

    /* Create a vertical box to stack buttons and options. */

    JPanel panel1 = new JPanel();
    panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
    int gapLine = (gapSize / 2) + 6; // vertical space between lines
    panel1.add(Box.createVerticalStrut(gapLine + 2)); // extra space at top

    /* Create a horizontal panel for the action buttons. */

    JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));

    pasteButton = new JButton("Paste");
    pasteButton.addActionListener(action);
    if (buttonFont != null) pasteButton.setFont(buttonFont);
    pasteButton.setMnemonic(KeyEvent.VK_P);
    pasteButton.setToolTipText("Replace entire text area with clipboard.");
    panel2.add(pasteButton);

    int gapButton = (2 * gapSize) + 6; // horizontal space between buttons
    panel2.add(Box.createHorizontalStrut(gapButton));

    convertButton = new JButton("Convert");
    convertButton.addActionListener(action);
    if (buttonFont != null) convertButton.setFont(buttonFont);
    convertButton.setMnemonic(KeyEvent.VK_N);
    convertButton.setToolTipText("Convert entire text area to plain text.");
    panel2.add(convertButton);

    panel2.add(Box.createHorizontalStrut(gapButton));

    copyButton = new JButton("Copy");
    copyButton.addActionListener(action);
    if (buttonFont != null) copyButton.setFont(buttonFont);
    copyButton.setMnemonic(KeyEvent.VK_C);
    copyButton.setToolTipText("Replace clipboard with entire text area.");
    panel2.add(copyButton);

    panel2.add(Box.createHorizontalStrut(gapButton));

    multiButton = new JButton("P+C+C");
    multiButton.addActionListener(action);
    if (buttonFont != null) multiButton.setFont(buttonFont);
    multiButton.setMnemonic(KeyEvent.VK_A);
    multiButton.setToolTipText("Paste + Convert + Copy buttons.");
    panel2.add(multiButton);

    panel2.add(Box.createHorizontalStrut(gapButton));

    exitButton = new JButton("Exit");
    exitButton.addActionListener(action);
    if (buttonFont != null) exitButton.setFont(buttonFont);
    exitButton.setMnemonic(KeyEvent.VK_X);
    exitButton.setToolTipText("Close this program.");
    panel2.add(exitButton);

    panel1.add(panel2);
    panel1.add(Box.createVerticalStrut(gapLine)); // space between panels

    /* Create a horizontal panel for the options. */

    JPanel panel3 = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));

    JLabel label1 = new JLabel("Font:", JLabel.RIGHT);
    if (buttonFont != null) label1.setFont(buttonFont);
    panel3.add(label1);

    int gapLabel = (gapSize / 3) + 2; // horizontal space between labels
    panel3.add(Box.createHorizontalStrut(gapLabel));

    fontNameDialog = new JComboBox(GraphicsEnvironment
      .getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
    fontNameDialog.setEditable(false); // user must select one of our choices
    if (buttonFont != null) fontNameDialog.setFont(buttonFont);
    fontNameDialog.setSelectedItem(fontName); // select default font name
    fontNameDialog.setToolTipText("Font name for display text.");
    fontNameDialog.addActionListener(action); // do last so don't fire early
    panel3.add(fontNameDialog);

    panel3.add(Box.createHorizontalStrut(gapLabel));

    TreeSet sizelist = new TreeSet(); // collect font sizes 10 to 99 in order
    word = String.valueOf(fontSize); // convert number to a string we can use
    sizelist.add(word);           // add default or user's chosen font size
    for (i = 0; i < FONT_SIZES.length; i ++) // add our preferred size list
      sizelist.add(FONT_SIZES[i]); // assume sizes are all two digits (10-99)
    fontSizeDialog = new JComboBox(sizelist.toArray()); // give user nice list
    fontSizeDialog.setEditable(false); // user must select one of our choices
    if (buttonFont != null) fontSizeDialog.setFont(buttonFont);
    fontSizeDialog.setSelectedItem(word); // selected item is our default size
    fontSizeDialog.setToolTipText("Point size for display text.");
    fontSizeDialog.addActionListener(action); // do last so don't fire early
    panel3.add(fontSizeDialog);

    panel3.add(Box.createHorizontalStrut(gapButton));

    JLabel label2 = new JLabel("Text Wrap:", JLabel.RIGHT);
    if (buttonFont != null) label2.setFont(buttonFont);
    panel3.add(label2);

    panel3.add(Box.createHorizontalStrut(gapLabel));

    wrapDialog = new JComboBox(WRAP_CHOICES);
    wrapDialog.setEditable(false); // user must select one of our choices
    if (buttonFont != null) wrapDialog.setFont(buttonFont);
    wrapDialog.setSelectedIndex(wrapIndex); // select default level
    wrapDialog.setToolTipText("Select scroll lines or wrap text.");
    wrapDialog.addActionListener(action); // do last so don't fire early
    panel3.add(wrapDialog);

    panel1.add(panel3);
    panel1.add(Box.createVerticalStrut(gapLine)); // extra space at bottom

    /* Put above boxed options in a panel that is centered horizontally.  Use
    FlowLayout's horizontal gap to add padding on the left and right sides. */

    JPanel panel4 = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
    panel4.add(panel1);

    /* Create a scrolling text area for the generated output. */

    outputText = new JTextArea(12, 40);
    outputText.setEditable(true); // user can change this text area
    outputText.setFont(new Font(fontName, Font.PLAIN, fontSize));
    outputText.setLineWrap(wrapIndex > 0); // if we allow text lines to wrap
    outputText.setMargin(new Insets(5, 6, 5, 6)); // top, left, bottom, right
    outputText.setWrapStyleWord(wrapIndex > 1); // wrap at word boundaries
    outputText.setText(
        "Convert Unicode characters to plain text characters, for example,"
      + " left and right quotation marks into plain quotes for web pages."
      + "\n\nType or paste your Unicode text here, then click the Convert"
      + " button.  Buttons affect the entire text area.  Use the Control-C or"
      + " Control-V keys if you want to copy or paste selected characters.\n\n"
      + COPYRIGHT_NOTICE + "\n");

    /* Create an entire panel just for the status message.  We do this so that
    we have some control over the margins.  Put the status text in the middle
    of a BorderLayout so that it expands with the window size. */

    JPanel panel5 = new JPanel(new BorderLayout(0, 0));
    statusDialog = new JLabel(EMPTY_STATUS, JLabel.LEFT);
    if (buttonFont != null) statusDialog.setFont(buttonFont);
    panel5.add(Box.createVerticalStrut(4), BorderLayout.NORTH);
    panel5.add(Box.createHorizontalStrut(10), BorderLayout.WEST);
    panel5.add(statusDialog, BorderLayout.CENTER);
    panel5.add(Box.createHorizontalStrut(10), BorderLayout.EAST);
    panel5.add(Box.createVerticalStrut(3), BorderLayout.SOUTH);

    /* Create the main window frame for this application.  Stack buttons and
    options above the text area.  Keep text in the center so that it expands
    horizontally and vertically.  Put status message at the bottom, which also
    expands. */

    mainFrame = new JFrame(PROGRAM_TITLE);
    Container panel6 = mainFrame.getContentPane(); // where content meets frame
    panel6.setLayout(new BorderLayout(0, 0));
    panel6.add(panel4, BorderLayout.NORTH); // buttons and options
    panel6.add(new JScrollPane(outputText), BorderLayout.CENTER); // text area
    panel6.add(panel5, BorderLayout.SOUTH); // status message

    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.setLocation(windowLeft, windowTop); // normal top-left corner
    if ((windowHeight < MIN_FRAME) || (windowWidth < MIN_FRAME))
      mainFrame.pack();           // do component layout with minimum size
    else                          // the user has given us a window size
      mainFrame.setSize(windowWidth, windowHeight); // size of normal window
    if (maximizeFlag) mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    mainFrame.validate();         // recheck application window layout
    mainFrame.setVisible(true);   // and then show application window

    /* Let the graphical interface run the application now. */

    outputText.requestFocusInWindow(); // give keyboard focus to text area
    loadConfig();                 // always load configuration data file here

  } // end of main() method

// ------------------------------------------------------------------------- //

/*
  addConversion() method

  This helper method makes it easier to add characters to the conversion table,
  and is called by the loadConfig() method.  The original string must have at
  least one character.  The replacement string may be empty.  Return <true> if
  successful and <false> otherwise.  An error almost always means a duplicate
  entry for the same original string.

  The conversion table is a tree whose branches are indexed by characters, and
  where values for leaves are indexed by the special <LEAF_KEY> constant.
*/
  static boolean addConversion(
    String oldText,               // non-empty original string (left side)
    String newText)               // arbitrary replacement string (right side)
  {
    int i;                        // index variable
    Integer key;                  // one character converted to mapping key
    int length;                   // size of original string in characters
    boolean result;               // true if successful, false otherwise
    TreeMap tree;                 // current location in mapping tree

    /* Find or create a branch in the tree indexed by the characters from the
    original string.  The string should not be empty, but this code will work
    even if there are no characters. */

    length = oldText.length();    // get size of original string in characters
    tree = convertMap;            // start at the base of the mapping tree
    for (i = 0; i < length; i ++)
    {
      key = new Integer((int) oldText.charAt(i)); // mapping needs Java object
      if (tree.containsKey(key) == false) // if no mapping for this character
        tree.put(key, new TreeMap()); // then default to an empty mapping
      tree = (TreeMap) tree.get(key); // and go to next branch in the tree
    }

    /* Insert the replacement string as a leaf in this tree.  Warn the caller
    with our result if we are replacing a previous value.  The caller is free
    to ignore our warning. */

    result = ! tree.containsKey(LEAF_KEY); // successful if no current value
    tree.put(LEAF_KEY, newText);  // add or replace current value for this leaf
    return(result);               // but <false> means new value is a duplicate

  } // end of addConversion() method


/*
  doConvertButton() method

  Convert the text area from Unicode characters to plain text characters.  The
  current caret position (selection) is reset to the end of the text.
*/
  static void doConvertButton()
  {
    int changeCount;              // number of changes made (not characters)
    int inputIndex;               // current character in <inputText>
    int inputLength;              // number of characters in <inputText>
    String inputText;             // input text from main dialog box
    int replaceIndex;             // index after characters we replace
    String replaceText;           // replacement text starting current input
    StringBuffer resultBuffer;    // faster than String for multiple appends
    int searchIndex;              // current search index in <inputText>
    Integer searchKey;            // search character as mapping key object
    TreeMap searchTree;           // current branch in conversion map

    /* Use the conversion table to replace characters in a given string.  The
    input is scanned from beginning to end, in a linear fashion, and starting
    from any given point, the string that replaces the most input characters is
    always used. */

    changeCount = 0;              // no strings have been replaced yet
    inputIndex = 0;               // start with the very first character
    inputText = outputText.getText(); // get input string from user's text area
    inputLength = inputText.length(); // get size of input string in characters
    resultBuffer = new StringBuffer(); // allocate empty buffer for result

    while (inputIndex < inputLength)
    {
      /* It is tempting to take the current input character, convert it to a
      string, and use that string as the default if no replacement can be found
      for this character.  However, that would create numerous small String
      objects, which would be slow and wasteful.  It's bad enough creating an
      Integer object as a mapping key for each input character! */

      replaceIndex = 999999999;   // just to keep compiler happy
      replaceText = null;         // indicate that we have no replacement yet
      searchIndex = inputIndex;   // start searching with this input character
      searchTree = convertMap;    // search from root of the conversion map
      while (searchIndex < inputLength)
      {
        searchKey = new Integer((int) inputText.charAt(searchIndex));
        if (searchTree.containsKey(searchKey))
        {
          searchIndex ++;         // continue searching with next character
          searchTree = (TreeMap) searchTree.get(searchKey); // new tree branch
          if (searchTree.containsKey(LEAF_KEY)) // is there a replacement?
          {
            replaceIndex = searchIndex; // remember how much input to consume
            replaceText = (String) searchTree.get(LEAF_KEY); // substitution
          }
        }
        else                      // input text not found, or too long
          break;                  // exit early from <while> loop
      }

      /* If we found a replacement string, then use that string and index the
      input past the characters that it replaces. */

      if (replaceText == null)    // did we find a replacement string?
        resultBuffer.append(inputText.charAt(inputIndex ++));
                                  // no, copy one input character as-is
      else                        // yes, use the replacement string
      {
        changeCount ++;           // one more substitution has been made
        inputIndex = replaceIndex; // index after characters we replace
        resultBuffer.append(replaceText); // copy the replacement string
      }
    }

    /* Set the GUI dialog box to our result, and indicate how many changes we
    made.  Changes count substitutions, not an exact number of characters. */

    outputText.setText(resultBuffer.toString()); // show user converted string
    outputText.requestFocusInWindow(); // give keyboard focus to text area
    statusDialog.setText("Text has " + prettyPlural(outputText.getText()
      .length(), "character") + " with " + prettyPlural(changeCount, "change")
      + ".");

  } // end of doConvertButton() method


/*
  doCopyButton() method

  Copy the entire text area to the system clipboard.  Remember the current
  caret position (selection) and restore that afterwards.  No conversion takes
  place here.
*/
  static void doCopyButton()
  {
    int end, start;               // text positions for caret and/or selection

    end = outputText.getSelectionEnd(); // remember current position in text
    start = outputText.getSelectionStart();
    outputText.selectAll();       // select all text in the dialog box
    outputText.copy();            // place that text onto the clipboard
    outputText.select(start, end); // restore previous caret position
    outputText.requestFocusInWindow(); // give keyboard focus to text area
    statusDialog.setText("Copied " + prettyPlural(outputText.getText()
      .length(), "character") + " to the clipboard.");
  }


/*
  doPasteButton() method

  Replace the entire text area with the contents of the system clipboard.  If
  the clipboard is empty (or does not contain text), we paste zero characters
  and all text is effectively removed from the dialog box.  The current caret
  position (selection) is immaterial.  No conversion takes place here.
*/
  static void doPasteButton()
  {
    outputText.setText(null);     // delete all text currently in dialog box
    outputText.paste();           // replace that text with the clipboard
    outputText.requestFocusInWindow(); // give keyboard focus to text area
    statusDialog.setText("Copied " + prettyPlural(outputText.getText()
      .length(), "character") + " from the clipboard.");
  }


/*
  loadConfig() method

  Load configuration data from a text file in the current working directory,
  which is usually the same folder as the program's *.class files.  Should we
  encounter an error, then print a message, but continue normal execution.
  None of the file data is critical to the operation of this program.
*/
  static void loadConfig()
  {
    StringBuffer buffer;          // faster than String for multiple appends
    char ch;                      // one character from input line
    Pattern convertPattern;       // compiled regular expression
    int i;                        // index variable
    BufferedReader inputFile;     // input character stream from text file
    int length;                   // size of a string in characters
    Matcher matcher;              // pattern matcher for regular expression
    String text;                  // one input line from file, or otherwise
    String word;                  // first command word on input line

    buffer = new StringBuffer();  // re-use same string buffer for each line
    convertPattern = Pattern.compile(
      "\\s*(?:(?:[Uu]\\+([0-9A-Fa-f]+))|(?:\"([^\"]*)\"))\\s*=\\s*(?:(?:[Uu]\\+([0-9A-Fa-f]+))|(?:\"([^\"]*)\"))(?:\\s+#.*)?\\s*");

    /* Open and read lines from the configuration data file. */

    try                           // catch specific and general I/O errors
    {
      inputFile = new BufferedReader(new InputStreamReader(new
        FileInputStream(dataFile), "UTF-8")); // UTF-8 encoded text file
      inputFile.mark(4);          // we may need to back up a few bytes
      i = inputFile.read();       // read byte-order marker if present
      if ((i >= 0) && (i != '\uFEFF') && (i != '\uFFFE')) // skip BOM or EOF?
        inputFile.reset();        // no, regular text, go back to beginning

      while ((text = inputFile.readLine()) != null)
      {
        /* Find the first word on the input line, which determines whether this
        is a command or a comment. */

        buffer.setLength(0);      // empty string buffer for command word
        i = 0;                    // start from beginning of input line
        length = text.length();   // number of characters to consider
        while ((i < length) && Character.isWhitespace(text.charAt(i)))
          i ++;                   // ignore leading white space (blanks, tabs)
        while ((i < length) && Character.isLetterOrDigit(ch = text.charAt(i)))
        {
          buffer.append(Character.toLowerCase(ch)); // accumulate first word
          i ++;                   // proceed to next input character
        }
        word = buffer.toString(); // convert buffer back to normal string
        if (word.equals("accept"))
        {
          /* Ignore "accept" commands from a "Font Rename" (Java) configuration
          file, so that we can use the same file with the same conversion table
          for this application too. */
        }
        else if (word.equals("convert"))
        {
          /* Input line should be the conversion of a non-empty Unicode string
          to an arbitrary Unicode string.  Double quotes (") are not allowed
          inside a string, but XML character references are interpreted. */

          matcher = convertPattern.matcher(text.substring(i)); // parse syntax
          if (matcher.matches())  // only if the entire substring matches
          {
            /* Parse left side (original) U+ notation or quoted string. */

            String left = matcher.group(1); // may be U+ notation on left
            if ((left != null) && (left.length() > 0)) // was U+ given?
            {
              try { i = Integer.parseInt(left, 16); } // parse U+ hex value
              catch (NumberFormatException nfe) { i = -999999999; } // if bad
              if ((i >= Character.MIN_VALUE) && (i <= Character.MAX_VALUE))
                left = String.valueOf((char) i); // convert as char to string
              else                // character number can't be Unicode
              {
                System.err.println("Invalid left convert value: " + text);
                continue;         // return to beginning of read loop
              }
            }
            else                  // Unicode U+ notation was not given
            {
              left = parseCharReference(matcher.group(2)); // quoted string
              if (left.length() == 0) // empty strings don't work well here
              {
                System.err.println("Empty left convert string: " + text);
                continue;         // return to beginning of read loop
              }
            }

            /* Parse right side (replacement) U+ notation or quoted string. */

            String right = matcher.group(3); // may be U+ notation on right
            if ((right != null) && (right.length() > 0)) // was U+ given?
            {
              try { i = Integer.parseInt(right, 16); } // parse U+ hex value
              catch (NumberFormatException nfe) { i = -999999999; } // if bad
              if ((i >= Character.MIN_VALUE) && (i <= Character.MAX_VALUE))
                right = String.valueOf((char) i); // convert as char to string
              else                // character number can't be Unicode
              {
                System.err.println("Invalid right convert value: " + text);
                continue;         // return to beginning of read loop
              }
            }
            else
              right = parseCharReference(matcher.group(4)); // quoted string

            if (addConversion(left, right) == false) // add to mapping table
              System.err.println("Duplicate left convert entry: " + text);
          }
          else
            System.err.println("Invalid convert syntax: " + text);
        }
        else if (word.length() > 0)
          System.err.println("Unknown configuration command: " + text);
        else if ((i < length) && (text.charAt(i) != '#'))
          System.err.println("Invalid configuration comment: " + text);
      }
      inputFile.close();          // try to close input file
    }

    catch (FileNotFoundException fnfe) // if our data file does not exist
    {
      /* Put special code here if you want to ignore the missing file. */

      if (dataFile.equals(DEFAULT_FILE) == false)
      {
        System.err.println("Configuration data file not found: " + dataFile);
        System.err.println("in current working directory "
          + System.getProperty("user.dir"));
      }
    }

    catch (IOException ioe)       // for all other file I/O errors
    {
      System.err.println("Unable to read configuration data from file "
        + dataFile);
      System.err.println("in current working directory "
        + System.getProperty("user.dir"));
      System.err.println(ioe.getMessage());
    }

    /* Use our default data if the configuration file was not found. */

    if (convertMap.size() == 0)   // if no conversions were defined
    {
      addConversion("\u2013", "-"); // En Dash
      addConversion("\u2014", "--"); // Em Dash
      addConversion("\u2018", "'"); // Left Single Quotation Mark
      addConversion("\u2019", "'"); // Right Single Quotation Mark
      addConversion("\u201A", "'"); // Single Low-9 Quotation Mark
      addConversion("\u201C", "\""); // Left Double Quotation Mark
      addConversion("\u201D", "\""); // Right Double Quotation Mark
      addConversion("\u201E", "\""); // Double Low-9 Quotation Mark
    }
  } // end of loadConfig() method


/*
  parseCharReference() method

  This method parses XML character references in a string and converts them to
  Unicode text.  The standard five character entity references are supported:

      &amp;   &   ampersand
      &apos;  '   apostrophe
      &gt;    >   greater than
      &lt;    <   less than
      &quot;  "   quotation mark

  Numeric character references are supported in both decimal and hexadecimal:
  &#8225; and &#x2021; are both the double dagger symbol.  See:

      http://www.w3.org/TR/REC-xml/#sec-references

  The input string is usually in plain text (ASCII), but this is not assumed or
  required.  Since Java currently limits characters to 16 bits, any character
  references that exceed 0xFFFF are not converted and are copied to the result
  unchanged.  (Java 5.0 has better support for extended character sets.)
*/
  static String parseCharReference(String input)
  {
    StringBuffer buffer;          // faster than String for multiple appends
    char ch;                      // one character from input string
    int digits;                   // number of digits found in reference
    boolean hexflag;              // true if reference is hexadecimal
    int i;                        // index variable
    int length;                   // size of input string in characters
    final int maxCharValue = 0xFFFF; // maximum binary value of a character
    int start;                    // index for start of character reference
    int value;                    // numeric value of character reference

    buffer = new StringBuffer();  // allocate empty string buffer for result
    i = 0;                        // start input string at the beginning
    length = input.length();      // get size of input string in characters
    while (i < length)            // do the whole input string
    {
      ch = input.charAt(i);       // get one character from input string
      if (ch == '&')              // we only recognize this escape code
      {
        start = i;                // remember where character reference begins
        i ++;                     // index of next character
        if (i >= length)          // is there really another character?
        {
          buffer.append(input.substring(start, i)); // copy malformed syntax
        }
        else if (input.startsWith("amp;", i)) // character entity reference
        {
          buffer.append('&');     // ampersand
          i += 4;                 // skip over remainder of this reference
        }
        else if (input.startsWith("apos;", i)) // character entity reference
        {
          buffer.append('\'');    // apostrophe
          i += 5;                 // skip over remainder of this reference
        }
        else if (input.startsWith("gt;", i)) // character entity reference
        {
          buffer.append('>');     // greater than
          i += 3;                 // skip over remainder of this reference
        }
        else if (input.startsWith("lt;", i)) // character entity reference
        {
          buffer.append('<');     // less than
          i += 3;                 // skip over remainder of this reference
        }
        else if (input.startsWith("quot;", i)) // character entity reference
        {
          buffer.append('"');     // quotation mark
          i += 5;                 // skip over remainder of this reference
        }

        else if ((ch = input.charAt(i++)) != '#') // next character must be #
        {
          i --;                   // "put back" <ch> because might start new &
          buffer.append(input.substring(start, i)); // copy malformed syntax
        }
        else                      // start of numeric reference
        {
          digits = 0;             // no digits found yet in numeric reference
          hexflag = false;        // assume that number is in decimal
          value = 0;              // start with zero for the numeric value
          while ((digits >= 0) && (i < length) && (value <= maxCharValue))
                                  // loop through remaining characters
          {
            ch = input.charAt(i++); // get one character from input string
            if ((digits == 0) && (!hexflag) && ((ch == 'X') || (ch == 'x')))
            {
              hexflag = true;     // now parsing in hexadecimal
            }
            else if ((!hexflag) && (ch >= '0') && (ch <= '9')) // decimal digit?
            {
              digits ++;          // one more digit found
              value = (value * 10) + (ch - '0'); // add decimal to total value
            }
            else if (hexflag && (ch >= '0') && (ch <= '9')) // hex digit?
            {
              digits ++;          // one more digit found
              value = (value << 4) + (ch - '0'); // add hex to total value
            }
            else if (hexflag && (ch >= 'A') && (ch <= 'F')) // hex digit?
            {
              digits ++;          // one more digit found
              value = (value << 4) + (ch - 'A' + 10); // add hex to total value
            }
            else if (hexflag && (ch >= 'a') && (ch <= 'f')) // hex digit?
            {
              digits ++;          // one more digit found
              value = (value << 4) + (ch - 'a' + 10); // add hex to total value
            }
            else if ((digits > 0) && (ch == ';')) // end of numeric reference?
            {
              digits = -1;        // use <digits> to flag successful finish
            }
            else                  // not an acceptable character
            {
              i --;               // "put back" <ch> because might start new &
              break;              // exit from <while> loop
            }
          }

          /* The number of digits gets set to negative if we properly finished
          the character reference. */

          if ((digits < 0) && (value <= maxCharValue)) // successful finish?
            buffer.append((char) value); // yes, convert binary value to char
          else                    // reference was not terminated properly
            buffer.append(input.substring(start, i)); // copy malformed syntax
        }
      }
      else                        // not inside a character reference
      {
        buffer.append(ch);        // append this character to result string
        i ++;                     // index of next character in input string
      }
    }
    return(buffer.toString());    // give caller our converted string

  } // end of parseCharReference() method


/*
  prettyPlural() method

  Return a string that formats a number and appends a lowercase "s" to a word
  if the number is plural (not one).  Also provide a more general method that
  accepts both a singular word and a plural word.
*/
  static String prettyPlural(
    long number,                  // number to be formatted
    String singular)              // singular word
  {
    return(prettyPlural(number, singular, (singular + "s")));
  }

  static String prettyPlural(
    long number,                  // number to be formatted
    String singular,              // singular word
    String plural)                // plural word
  {
    final String[] names = {"zero", "one", "two"};
                                  // names for small counting numbers
    String result;                // our converted result

    if ((number >= 0) && (number < names.length))
      result = names[(int) number]; // use names for small counting numbers
    else
      result = formatComma.format(number); // format number with digit grouping

    if (number == 1)              // is the number singular or plural?
      result += " " + singular;   // append singular word
    else
      result += " " + plural;     // append plural word

    return(result);               // give caller our converted string

  } // end of prettyPlural() method


/*
  showHelp() method

  Show the help summary.  This is a UNIX standard and is expected for all
  console applications, even very simple ones.
*/
  static void showHelp()
  {
    System.err.println();
    System.err.println(PROGRAM_TITLE);
    System.err.println();
    System.err.println("This is a graphical application.  You may give options on the command line:");
    System.err.println();
    System.err.println("  -? = -help = show summary of command-line syntax");
    System.err.println("  -d# = text file with configuration data; default is -d\"" + DEFAULT_FILE + "\"");
    System.err.println("  -r0 = scroll, do not wrap text lines in main dialog box");
    System.err.println("  -r1 = wrap text lines at arbitrary character boundaries");
    System.err.println("  -r2 = wrap text at word boundaries when possible (default)");
    System.err.println("  -u# = font size for buttons, dialogs, etc; default is local system;");
    System.err.println("      example: -u16");
    System.err.println("  -w(#,#,#,#) = normal window position: left, top, width, height;");
    System.err.println("      example: -w(50,50,700,500)");
    System.err.println("  -x = maximize application window; default is normal window");
    System.err.println();
    System.err.println(COPYRIGHT_NOTICE);
//  System.err.println();

  } // end of showHelp() method


/*
  userButton() method

  This method is called by our action listener actionPerformed() to process
  buttons, in the context of the main PlainText2 class.
*/
  static void userButton(ActionEvent event)
  {
    Object source = event.getSource(); // where the event came from
    if (source == convertButton)  // "Convert" button
    {
      doConvertButton();          // convert from Unicode to plain text
    }
    else if (source == copyButton) // "Copy" button
    {
      doCopyButton();             // trivial, but call someone else to do this
    }
    else if (source == exitButton) // "Exit" button
    {
      System.exit(0);             // always exit with zero status from GUI
    }
    else if (source == fontNameDialog) // font name for output text area
    {
      /* We can safely assume that the font name is valid, because we obtained
      the names from getAvailableFontFamilyNames(), and the user can't edit
      this dialog field. */

      fontName = (String) fontNameDialog.getSelectedItem();
      outputText.setFont(new Font(fontName, Font.PLAIN, fontSize));
    }
    else if (source == fontSizeDialog) // point size for output text area
    {
      /* We can safely parse the point size as an integer, because we supply
      the only choices allowed, and the user can't edit this dialog field. */

      fontSize = Integer.parseInt((String) fontSizeDialog.getSelectedItem());
      outputText.setFont(new Font(fontName, Font.PLAIN, fontSize));
    }
    else if (source == multiButton) // multiple button: Paste + Convert + Copy
    {
      pasteButton.doClick();      // pretend user clicked "Paste" button
      convertButton.doClick();    // pretend user clicked "Convert" button
      copyButton.doClick();       // pretend user clicked "Copy" button
    }
    else if (source == pasteButton) // "Paste" button
    {
      doPasteButton();            // trivial, but call someone else to do this
    }
    else if (source == wrapDialog) // controls text line scrolling or wrapping
    {
      wrapIndex = wrapDialog.getSelectedIndex(); // index into choice list
      outputText.setLineWrap(wrapIndex > 0); // if we allow text lines to wrap
      outputText.setWrapStyleWord(wrapIndex > 1); // wrap at word boundaries
    }
    else                          // fault in program logic, not by user
    {
      System.err.println("Error in userButton(): unknown ActionEvent: "
        + event);                 // should never happen, so write on console
    }
  } // end of userButton() method

} // end of PlainText2 class

// ------------------------------------------------------------------------- //

/*
  PlainText2User class

  This class listens to input from the user and passes back event parameters to
  a static method in the main class.
*/

class PlainText2User implements ActionListener
{
  /* empty constructor */

  public PlainText2User() { }

  /* button listener, dialog boxes, etc */

  public void actionPerformed(ActionEvent event)
  {
    PlainText2.userButton(event);
  }

} // end of PlainText2User class

/* Copyright (c) 2009 by Keith Fenske.  GNU General Public License (GPLv3+). */
