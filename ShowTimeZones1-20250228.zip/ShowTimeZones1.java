/*
  Show Time Zones #1 - Show Available Java Time Zones
  Written by: Keith Fenske, http://kwfenske.github.io/
  Monday, 3 February 2025
  Java class name: ShowTimeZones1
  Copyright (c) 2025 by Keith Fenske.  Apache License or GNU GPL.

  This is a Java 1.4 console application to print a list of the installed time
  zones for the current computer and version of Java.  There are no options or
  command-line parameters.  Starting with Java 8, there is a newer "java.time"
  package (API) that also does time zones.

  Apache License or GNU General Public License
  --------------------------------------------
  ShowTimeZones1 is free software and has been released under the terms and
  conditions of the Apache License (version 2.0 or later) and/or the GNU
  General Public License (GPL, version 2 or later).  This program is
  distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY,
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
  PARTICULAR PURPOSE.  See the license(s) for more details.  You should have
  received a copy of the licenses along with this program.  If not, see the
  http://www.apache.org/licenses/ and http://www.gnu.org/licenses/ web pages.
*/

import java.io.*;                 // standard I/O
import java.util.*;               // calendars, dates, lists, maps, vectors

public class ShowTimeZones1
{
  public static void main(String[] args)
  {
    /* introduction */

    System.out.println();         // blank line
    System.out.println("Available Java Time Zones");
    System.out.println("Version " + System.getProperty("java.version")
      + " from " + System.getProperty("java.vendor"));
    System.out.println(System.getProperty("os.name") + " ("
      + System.getProperty("os.version") + ") "
      + System.getProperty("os.arch"));
    System.out.println((new Date()).toString());
    System.out.println();

    /* time zones */

    String[] idlist = TimeZone.getAvailableIDs();
                                  // by GMT offset, strict Unicode for name
    Arrays.sort(idlist, java.text.Collator.getInstance());
                                  // alphabetical by name in current locale
    System.out.println("This version of Java has " + idlist.length
      + " time zone IDs as follows, where \"with DST\" means");
    System.out.println("some form of daylight saving time (summer time):");
    System.out.println();

    StringBuffer buffer = new StringBuffer(); // for building up output
    for (int i = 0; i < idlist.length; i ++)
    {
      buffer.setLength(0);        // empty output buffer
      String id = idlist[i];      // time zone ID (text string)
      buffer.append("GMT");       // start with offset from GMT (UTC)
      TimeZone tz = TimeZone.getTimeZone(id); // internal time zone object
      int raw = tz.getRawOffset(); // total milliseconds from GMT (UTC)
      buffer.append((raw < 0) ? '-' : '+'); // use plus for zero, positive
      raw = Math.abs(raw) / 1000; // total seconds, throw away milliseconds
      int seconds = raw % 60;     // only the seconds part
      raw = raw / 60;             // total minutes, throw away seconds
      int minutes = raw % 60;     // only the minutes part
      int hours = raw / 60;       // only the hours part
      if (hours < 10) buffer.append("0"); // two-digit hours
      buffer.append(String.valueOf(hours));
      buffer.append(":");
      if (minutes < 10) buffer.append("0"); // two-digit minutes
      buffer.append(String.valueOf(minutes));
      if (seconds > 0)            // found in Riyadh87 to Riyadh89
      {
        buffer.append(":");
        if (seconds < 10) buffer.append("0"); // two-digit seconds
        buffer.append(String.valueOf(seconds));
      }
      buffer.append(" ");
      buffer.append(id);          // put time zone ID
      if (tz.useDaylightTime()) buffer.append(" (with DST)");
      System.out.println(buffer.toString());
    }

    /* conclusion */

    System.out.println();
    System.out.println("[end]");

  } // end of main() method

} // end of ShowTimeZones1 class

/* Copyright (c) 2025 by Keith Fenske.  Apache License or GNU GPL. */
